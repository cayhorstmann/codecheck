def main():
        name = "Udacity"
        last = "y"
        print last

if __name__ == "__main__":
    main()
